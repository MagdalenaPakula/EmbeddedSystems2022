#ifndef __COMMON_DEFINITIONS_H__
#define __COMMON_DEFINITIONS_H__

#define DIODA_PRAWA		_BIT(8)
#define DIODA_LEWA		_BIT(9)

#endif //__COMMON_DEFINITIONS_H__
