#include "types.h"
#include "pff.h"
#ifndef SD_H_
#define SD_H_

#define SPI_SS_PIN	11
#define SD_Disable() IO0SET = 1 << 11
#define SD_Enable() IO0CLR = 1 << 11
#include "integer.h"
#define	CMDREAD		17
#define	CMDWRITE	24
#define	CMDREADCSD	9

// initialise SD card - initialise reader
CHAR sdInit(void);

// check SD state - checking file system
CHAR sdState(void);

// sending command
void sdCommand(BYTE cmd, WORD parX, WORD parY);

// 8bit response
BYTE sdResp8b(void);

// if error occurs in 8bit response
void sdResp8bError(BYTE value);

// 16bit response
WORD sdResp16b(void);

//reading sector from SD card - we are providing address, buffor and length
esint8 sd_readSector(euint32 address, euint8* buffor, euint16 length);

//writing into SD card sector - providing address and buffor
esint8 sd_writeSector(euint32 address, BYTE* buffor);

FRESULT listDir(char *path, uint8 first);

uint32 filesList(char* path, char* list);

#endif /* SD_H_ */
