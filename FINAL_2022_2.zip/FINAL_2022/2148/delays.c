static void delay(tU32 seconds) {
  T0TCR = TIMER_RESET; //Stop and reset
  T0PR = PERIPHERAL_CLOCK - 1; //unit in prescaler
  T0MR0 = seconds;
  T0IR = TIMER_ALL_INT; //reset irq flags
  T0MCR = MR0_S; //Count to MRO value
  T0TCR = TIMER_RUN; //Run timer

  //Checks if timer works

  while (T0TCR & TIMER_RUN) {}
}

static void sdelay(tU32 seconds) {
  T0TCR = TIMER_RESET; //Stop and reset
  T0PR = PERIPHERAL_CLOCK - 1; //unit in prescaler
  T0MR0 = seconds;
  T0IR = TIMER_ALL_INT; //reset irq flags
  T0MCR = MR0_S;  //Count to MRO value
  T0TCR = TIMER_RUN;  //Run timer
  //Checks if timer works
  while (T0TCR & TIMER_RUN) {}
}
