#include <lpc2xxx.h>
#include <general.h>
#include <lpc2xxx.h>
#include "lcd.h"

extern char soundBufor0[10240];
extern char soundBufor1[10240];
extern int buforFlag;
extern FATFS fatfs; /* File system object */
extern DWORD rc;
extern WORD br;
extern char data_buffer_32[512];
extern char nazwa[12];
extern char pliki[256*12];
extern int32 titleIndex;
extern uint32 filesCount;

void songNameOnLCD(char *nazwa, int32 isMusicPlaying);

void init()
{
	rc = pf_mount(&fatfs);
  	if (rc){
  		LcdText("Mounting error");
  		if( FR_DISK_ERR == rc || FR_NOT_READY == rc ){
  			LcdText("Interface error");
  		}else if( FR_NO_FILESYSTEM == rc ){
  			LcdText("Wrong file\nsystem");
  		}
  	}


	rc = listDir("/", TRUE); //list directories on sd card
  	if (rc){
  		simplePrintf("listDir, rc=%x\n", rc);
  	}


	filesCount = filesList("/", pliki) ; // create file list
	if( filesCount == 0){
		simplePrintf("fileList => no files or unreadable");
	}

	simplePrintf("WAV File number: %d\n", filesCount);


	setSongName(nazwa, pliki, titleIndex);


	rc = pf_open(nazwa);

	  initSpi();
	  sdInit();
	  adjustMotor();
}

static void init_irq(tU32 period, tU8 duty_cycle) {
  //Initialize VIC for irq from Timer #1
  VICIntSelect &= ~TIMER_1_IRQ; //interrupt from Timer #1 assigned to IRQ (not to FIQ)
  VICVectAddr5 = (tU32) IRQ_Test; //interrupt address
  VICVectCntl5 = VIC_ENABLE_SLOT | TIMER_1_IRQ_NO;
  VICIntEnable = TIMER_1_IRQ; // Assign and unlock slot in VIC from Timer #1

  T1TCR = TIMER_RESET; //Stop and reset
  T1PR = 0; //Prescaler unused
  T1MR0 = ((tU64) period) * ((tU64) PERIPHERAL_CLOCK) / 1000000;
  T1MR1 = (tU64) T1MR0 * duty_cycle / 100; //Fill
  T1IR = TIMER_ALL_INT; //reset irq flags
  T1MCR = MR0_I | MR0_R; //Generate periodic interrupts for MR0 and additional for MR1
  T1TCR = TIMER_RUN;  //Run timer
}

static void delay(tU32 seconds) {
  T0TCR = TIMER_RESET; //Stop and reset
  T0PR = PERIPHERAL_CLOCK - 1; //unit in prescaler
  T0MR0 = seconds;
  T0IR = TIMER_ALL_INT; //reset irq flags
  T0MCR = MR0_S; //Count to value MRO then stop
  T0TCR = TIMER_RUN; //run timer

  //Checks if timer works

  while (T0TCR & TIMER_RUN) {}
}

void setSongName(char *nazwa, char *pliki, int titleIndex)
{
	for(int m = 0; m < 8; m++)
	{
		nazwa[m] = pliki[titleIndex*12+m];
	}
	//LcdText(nazwa, TRUE);
	rc = pf_open(nazwa);

}

void fillBuforWav()
{
    for (int k = 0; k < 20; k++) {
    	rc = pf_read(data_buffer_32, sizeof(data_buffer_32), &br);

    	if (buforFlag % 2 == 0) {
        for (int i = 0; i < 512; i++) {
          soundBufor0[512 * k + i] = data_buffer_32[i];
        }
      } else {
        for (int i = 0; i < 512; i++) {
          soundBufor1[512 * k + i] = data_buffer_32[i];
        }
      }
    }

}

void songNameOnLCD(char *nazwa, int32 isMusicPlaying)
{
	char message[16];

	if(isMusicPlaying == 1)
	{
		message[0] = '|';
		message[1] = '>';
	}
	else
	{
		message[0] = 'I';
		message[1] = 'I';
	}

	message[2] = ' ';

	for(int i = 0; i < 12; i++)
	{
		message[3+i] = nazwa[i];
	}

	message[15] = ' ';

	LcdText(message);
}
