#include <lpc2xxx.h>
#include "spi.h"
// we set SPI to generate clock for data transfer with frequency 15MHZ
void setSpiSpeed(BYTE speed)
{
	speed &= 0xFE; // 0xFE = 254 in decimal
	if ( speed < SPI_PRESCALE_MIN  )
	{
		speed = SPI_PRESCALE_MIN;
	}

	SPI_PRESCALE_REG = speed;

}
void initSpi(void)
{
    // setup GPIO (general purpose input-output)
	IODIR0 |= (1<<SPI_SCK_PIN)|(1<<SPI_MOSI_PIN)|(1<<SPI_SS_PIN); // |= - output, 1<< pin (np P0.11) // all of them are from master
	IODIR0 &= ~(1<<SPI_MISO_PIN); // &= - input // MISO is from card to master, so here we have negation (remember that IODIR is used to set direction of pins)
									// &= (1<<10) | (1<<11)
	// set Chip-Select high - unselect card
	IOSET0 = (1<<SPI_SS_PIN); 

	// reset Pin-Functions
	SPI_PINSEL &= ~( (3<<SPI_SCK_FUNCBIT) | (3<<SPI_MISO_FUNCBIT) |
		(3<<SPI_MOSI_FUNCBIT) | (3<<SPI_SS_FUNCBIT) ); // Pin function Select register 0 (PINSEL1 - 0xE002 C000)

	SPI_PINSEL |= ( (1<<SPI_SCK_FUNCBIT) | (1<<SPI_MISO_FUNCBIT) |
		(1<<SPI_MOSI_FUNCBIT) );

	// enable SPI-Master
	S0SPCR = (1<<MSTR)|(0<<CPOL); // Clock Polarity and Master Mode Select in SPI0 Control Registers

	// setting SPI speed - during initialization it should be low (low means around 400kHZ)
	setSpiSpeed(150);

	CHAR i = 0;
	/* Send 20 spi commands with card not selected */
	for(i=0;i<21;i++)
	{
		my_spiSend(0xff);
	}
}

BYTE my_spiSend(BYTE outgoing)
{
	BYTE incoming;

	S0SPDR = outgoing;
	while( !(S0SPSR & (1<<SPIF)) ) ; // S0SPSR - SPI Status Register
	incoming = S0SPDR;				// SPI Data Register

	return(incoming);
}


BYTE spiSend(BYTE toSend)
{

	BYTE incoming;
	S0SPDR = toSend; // SPI0 Data Register - transmit data is provided to the SPI by writing to this register
	while( !(S0SPSR & (1<<SPIF)) ) ; //S0SPSR - SPI0 Status Register (read only), SPIF (SPI Transfer Complete Flag)

	incoming = S0SPDR;

	return incoming;
}
void send_SPI(unsigned char indata)
{
  S0SPDR = indata;
  while(!(S0SPSR & 0x80));

}

